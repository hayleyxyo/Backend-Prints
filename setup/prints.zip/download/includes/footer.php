	<footer>
		<p><?php print date('l, jS F Y'); ?></p>
	</footer>
