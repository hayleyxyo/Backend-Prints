<?php

	class Data {

		protected $pdo;
		protected $CONFIG;
		public $data=array();
		protected $sql=array();

		function __construct($pdo,$config) {
			$this->pdo=$pdo;
			$this->CONFIG=$config;
		}

		/*	Data Model
			================================================================ */

			function count() {
				return $this->pdo->query($this->sql['count'])->fetchColumn();
			}

			function selectAll() {
				return $this->pdo->query($this->sql['selectAll'])->fetchAll();
			}

			function select($id=0) {
				$row=$this->pdo->query(sprintf($this->sql['select'],intval($id)))->fetch();
				if(!$row) return array();
				$this->data=array_merge($this->data,$row);
				return $row;
			}

			function add($data) {
				$pds=$this->pdo->prepare($this->sql['insert']);
				$pds->execute($data);
				return $this->pdo->lastInsertId();
			}

			function update($data) {
				$pds=$this->pdo->prepare($this->sql['update']);
				$pds->execute($data) or die("oops");
			}

			function delete($id) {
				$pds=$this->pdo->prepare($this->sql['delete']);
				$pds->execute($id);
			}

			function execute($sql,$data) {
				$pds=$this->pdo->prepare($sql);
				$pds->execute($data);
				return $pds;
			}

			function fetch($sql,$data) {
				return $this->execute($sql,$data)->fetch();
			}

			function fetchColumn($sql,$data,$col=0) {
				return $this->execute($sql,$data)->fetchColumn($col);
			}

			function checkDuplicate($field,$id=0) {
				$pds=$this->pdo->prepare($this->sql['duplicate']);
				$data=array($field,$id);
				$pds->execute($data);
				if($pds->fetchColumn()) return true;
				return false;
			}

			function error() {
				return false;
			}


		/*	View
			================================================================ */

			function interpolate($file,$variables=null) {
				if(!$variables) $variables=$GLOBALS;
				extract($variables);
				ob_start();
				include $file;
				return ob_get_clean();
			}

			function content($template) {
				return $this->interpolate($template,$this->data);
			}

			function showAll($id=0) {
				$options=array();
				foreach($this->selectALL() as $row) {
					$selected = $row['id']==$id ? ' selected' : '';
					$options[]="<option value=\"$row[id]\"$selected>$row[aka]: $row[givenname] $row[familyname]</option>";
				}
				return implode('',$options);
			}

			function displayErrors($errors) {
				$this->data['errors'] = $errors ? sprintf('<p class="error">%s</p>',implode('<br>',$errors)) : '';
				return $this->data['errors'];
			}


		/*	Controller
			================================================================ */
			function getPage($page,$max) {
				//	$page is the URL variable
				$page=intval(@$_GET[$page]);
				if($page<1) $page=1;
				if($page>$max) $page=$max;
				return $page;
			}

			function id() {
				return intval(@$_POST['select']);
			}

			function GetData() {
				$this->data=array();
				return $this->data;
			}

			function processButtons() {
				$id=0;
				$error=null;
				if(isset($_POST['select'])) {
					//	$id=intval(@$_POST['select']);
				}
				if(isset($_POST['insert'])) {
					//	return $this->add($_POST['givenname'],$_POST['familyname'],$_POST['aka']);
				}
				if(isset($_POST['update'])) {
					//	$id=intval($_POST['id']);
					//	$this->artists->update($_POST['givenname'],$_POST['familyname'],$_POST['aka'],$id);
					//	return $id;
				}
				if(isset($_POST['delete'])) {
					//	$id=intval($_POST['id']);
					//	$this->artists->delete($id);
					//	return $id;
				}
				return $id;
			}
		/*	================================================================ */

		function prepared($string,$data) {
			$indexed=$data==array_values($data);
			foreach($data as $k=>$v) {
				if(is_string($v)) $v="'$v'";
				if($indexed) $string=preg_replace('/\?/',$v,$string,1);
				else $string=str_replace(":$k",$v,$string);
			}
			return $string;
		}


	}

?>
