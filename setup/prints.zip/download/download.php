<?php
	//ob_start();
	if(isset($_POST['download'])) {
		$email=trim($_POST['email']);
		if(preg_match('/.+@.+\..+/',$email)) {

			$printzip='prints.zip';
			`zip -r ../$printzip ./`;
			if(file_exists("../$printzip")&&is_readable("../$printzip")) {
				//ob_end_clean();
				$data=file_get_contents("../$printzip");
				$data=chunk_split(base64_encode($data),72);

				$boundary=md5(time());

				$header=array();
				$date=date("r");			
					$header[]="Date: $date";
				$from='mark@comparity.net';
					$header[]="From: $from";
					$header[]="Reply-To: $from";
				$header[]="Content-Type: multipart/mixed; boundary=\"mixed--$boundary\"";
				$header=implode("\r\n",$header)."\r\n\r\n";

				$message='Attached is the zip file for the Prints web site';


				//	Watch the spacing below. Attachments and messages don’t work otherwise ...

				$body=<<<BODY
--mixed--$boundary

$message

--mixed--$boundary
Content-Type: application/zip; name="$printzip"
Content-Transfer-Encoding: base64
Content-Disposition: attachment

$data
--mixed--$boundary
BODY;
				$subject='The Artworks Formally Known as Prints';
				mail($email,$subject,$body,$header,"-f$from");
			}
		}
		else {
			$printzip='prints.zip';
			`zip -r ../$printzip ./`;
			if(file_exists("../$printzip")&&is_readable("../$printzip")) {
				$size=filesize("../$printzip");
				print "Size: $size<br>";
				header("Content-Type: application/octet-stream");
				header("Content-Length: $size");
				header("Content-Disposition: attachment; filename=$printzip");
				header("Content-Transfer-Encoding: binary");
				$file=@fopen("../$printzip",'rb');
				ob_end_clean();	//	Required to prevent problems with zip files
				if($file) fpassthru($file);
				else $ok=false;
				
			}
		}
	}
?>
<?php
	$pageTitle='Download this Site';
	include('includes/header.php');
?>
	<link rel="stylesheet" type="text/css" href="styles/forms.css">
	<link rel="stylesheet" type="text/css" href="styles/styles.css">
</head>
<body>
<div id="body">
	<h1><?php print $pageTitle; ?></h1>
	<p>Please Click on the Download button.<br>
		If you prefer to have the file emailed to you instead, enter your email address.</p>
	<form action="" method="post">
		<p><label>Email Address: <input type="text" name="email"></label></p>
		<input type="submit" name="download" value="Download this Site">
	</form>
</div>
</body>
</html>
