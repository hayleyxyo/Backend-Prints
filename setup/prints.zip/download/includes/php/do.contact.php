<?php
	require_once 'includes/classes/class.contact.php';
#	$artists=new Artists($pdo,$CONFIG);

#	list($id,$errors)=$artists->processButtons();
#	extract($artists->data);

	$contact=new Contact('localhost','mark@manngo.net',$pdo);
	if($contact->process()) {
		redirect('/');
		exit;
	}
	extract($contact->data);



?>
