DROP TABLE IF EXISTS users;
CREATE TABLE users (
	id INT UNSIGNED AUTO_INCREMENT,
	email VARCHAR(60) NOT NULL,
	familyname VARCHAR(40) NOT NULL,
	givenname VARCHAR(40) NOT NULL,
	password CHAR(40) NOT NULL, -- use with sha(),
	confirmation CHAR(23) DEFAULT NULL,
	updated DATETIME DEFAULT now(),
	passwdexpires DATETIME DEFAULT NULL,
	admin BOOLEAN NOT NULL DEFAULT FALSE,
	remember char(23) DEFAULT NULL,
	cart TEXT DEFAULT NULL,
	active BOOLEAN NOT NULL DEFAULT FALSE,
	PRIMARY KEY (id),
	UNIQUE INDEX email(email)
) ENGINE=INNODB;
INSERT INTO users(email,familyname,givenname,passwd)
VALUES('mark@comparity.net','Mark','Simon',sha('mark'));