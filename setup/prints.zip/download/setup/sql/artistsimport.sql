DELETE FROM artists;
ALTER TABLE artists AUTO_INCREMENT=1;
INSERT INTO artists (givenname,familyname,aka)
VALUES
	('Sandro','Boticelli','boticelli'),
	('Leonardo','Da Vinci','davinci'),
	('Michelangelo',NULL,'michelangelo'),
	('Piet','Mondrian','mondrian'),
	('Paul','Gauguin','gauguin'),
	('Albrecht','Durer','durer'),
	('Jackson','Pollock','pollock'),
	('Henri','Rousseau','rousseau'),
	('Paul','Klee','klee'),
	('Henri','Matisse','matisse'),
	('Edgar','Degas','degas'),
	('Edouard','Manet','manet'),
	('James','Whistler','whistler'),
	('Pierre-Aguste','Renoir','renoir'),
	('Rembrandt','Van Rijn','rembrandt')
;
INSERT INTO artists (givenname,familyname,aka)
VALUES
	('Hieronymus','Bosch','bosch'),
	('John','Constable','constable'),
	('Thomas','Gainsborough','gainsborough'),
	('Vincent','Van Gogh','vangogh'),
	(NULL,'El Greco','elgreco'),
	('Juan','Gris','gris'),
	('Ando','Hiroshige','hiroshige'),
	('Amedeo','Modigiliani','modigiliani'),
	('Claude','Monet','monet'),
	('Alfred','Sisley','sisley'),
	('Joseph','Turner','turner')
;
