<?php
	require_once 'includes/classes/class.users.php';
	$users=new Users($pdo,$CONFIG);

	if($users->processButtons()===true) {
		redirect('/');
		exit;
	}
	extract($users->data);

?>
