<?php

	//	Login & Logout
		require_once('includes/php/do.login.php');

	//	Ordering & Shopping Cart
		require_once('includes/classes/class.orders.php');
		require_once('includes/classes/class.cart.php');

		$cart=new Cart($pdo,'cart');

	//	Process Shopping
		$cart->processButtons();
	//	Display Shopping Cart
#		list($checkoutItems,$totalPrice)=$cart->showList(true);
		$cart->showList(true);
		extract($cart->data);

?>
