<?php

	require_once 'includes/classes/class.users.php';
	$users=new Users($pdo,$CONFIG);

	$users->checkLogin();
return;

?>
