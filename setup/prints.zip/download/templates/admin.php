	<p><?php print "Welcome $_SESSION[givenname] $_SESSION[familyname]"; ?></p>
	<p><a href="/prints">Manage Prints</a><br>
		<a href="/artists">Manage Artists</a><br>
		<a href="/users">Manage Customers</a>
	</p>
