<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

	require_once 'includes/classes/class.catalogue.php';
	$catalogue=new Catalogue($pdo,$CONFIG);

	// Page
		$printCount=$catalogue->count();
		$pageCount=ceil($printCount/$cataloguePageSize);
		$page=$catalogue->getPage('page',$pageCount);
		$firstPrint=($page-1)*$cataloguePageSize;

	//	Catalogue
		$prints=$catalogue->showSome($cataloguePageSize,$firstPrint);
		$navigation=pager($page,$pageCount);

?>
