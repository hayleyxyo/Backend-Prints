<?php

	require_once 'class.data.php';

	class Orders extends Data {
		protected $sql=array(
			'select'=>'SELECT id,customerid,total,orderdate FROM orders WHERE id=%s',
			'selectAll'=>'SELECT id,customerid,total,orderdate FROM orders',
			'insert'=>'INSERT INTO orders (customerid,total,orderdate) VALUES (:customerid,:total,:orderdate)',
			'insertItems'=>'INSERT INTO orderitems(orderid,printid,quantity,price,shipdate) VALUES(:orderid,:printid,:quantity,:price,:shipdate)',
			'update'=>'UPDATE orders SET customerid=:customerid, total=:total, orderdate=:orderdate WHERE id=:id',
			'updateItems'=>'UPDATE orders SET orderid=:orderid, printid=:printid, orderdate=:orderdate WHERE id=:id',
			'delete'=>'DELETE FROM artists WHERE id=?',
			'duplicate'=>'SELECT count(*) FROM artists WHERE aka=? and id<>?',
		);

		/*	View
			================================================================ */

			function prepare($id=0) {
				$this->data['list']=$this->showList($id);
			}

			function showList($id=0) {
				$options=array();
				foreach($this->selectAll() as $row) {
					$selected = $row['id']==$id ? ' selected' : '';
					$options[]="<option value=\"$row[id]\"$selected>$row[aka]: $row[givenname] $row[familyname]</option>";
				}
				return implode('',$options);
			}

		/*	Controller
			================================================================ */

			function noData() {
				$data=array(
					'givenname'=>'',
					'familyname'=>'',
					'aka'=>'',
					'id'=>0,
				);
				$this->data=array_merge($this->data,$data);
				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;

			}

			function getData() {
				$data=array(
					'givenname'=>trim($_POST['givenname']),
					'familyname'=>trim($_POST['familyname']),
					'aka'=>trim($_POST['aka']),
					'id'=>intval(@$_POST['id'])
				);

				$this->data=array_merge($this->data,$data);

				$this->prepare($this->data['id']);

				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;
			}

			function processButtons() {
				$id=0;
				$error=null;
				$this->noData();

				if(isset($_POST['select'])) {
					$id=intval(@$_POST['select']);
					if($id) $this->select($id);
				}

				if(isset($_POST['insert'])) {
					$data=$this->getData();
					$id=$data['id'];
					$error=$this->error();
					if($error) $id=0;
					else $id=$this->add(array('artistid'=>$data['artistid'],'title'=>$data['title'],
							'price'=>$data['price'],'size'=>$data['size'],'description'=>$data['description'],'src'=>$src));
				}


				if(isset($_POST['update'])) {
					$data=$this->getData();
					$id=$data['id'];
					$error=$this->error(false);
					if($error) $id=0;
					else  $this->update(array('artistid'=>$data['artistid'],'title'=>$data['title'],
							'price'=>$data['price'],'size'=>$data['size'],'description'=>$data['description'],'src'=>$src,'id'=>$id));
					$this->data['src']=$src;
				}

				if(isset($_POST['delete'])) {
					$data=$this->getData();
					$id=$data['id'];
					$this->delete(array($id));
					$this->noData();
					$id=0;
				}

				//	Fall Through
					$this->prepare($id);
					$error=$this->displayErrors($error);
					return array($id,$error);
			}

		function error() {
			//	Uses $_POST data
			$errors=array();
			//	Required
				if(!$this->data['givenname']) $errors[]='Missing Given Name';
				if(!$this->data['familyname']) $errors[]='Missing Family Name';
				if(!$this->data['aka']) $errors[]='Missing Artist Alias';
				elseif($this->checkDuplicate($this->data['aka'],$id)) $errors[]='Artist Alias already exists';
			return $errors?:false;
		}

	}

?>
