<?php

	require_once 'class.data.php';

	class Users extends Data {
		protected $sql=array(
			'select'=>'SELECT id,givenname,familyname,email,password,admin,contributor FROM users WHERE id=%s',
			'selectAll'=>'SELECT id,details FROM userdetails',
			'insert'=>'INSERT INTO users(email,givenname,familyname,password,confirmation) VALUES (:email,:givenname,:familyname,:password,:confirmation)',
			'update'=>'UPDATE users SET givenname=:givenname, familyname=:familyname, email=:email, admin=:admin, contributor=:contributorpassword=:password WHERE id=:id',
			'delete'=>'DELETE FROM users WHERE id=?',
			'duplicate'=>'SELECT count(*) FROM users WHERE email=? AND id<>?',
			'login'=>'SELECT id,familyname,givenname,admin FROM users WHERE email=:email AND password=:password',
			'confirm'=>'UPDATE users SET active=1, confirmation=null WHERE id=:id AND confirmation=:confirmation AND email=:email',
		);

		/*	View
			================================================================ */

			function prepare($id=0) {
				$this->data['list']=$this->showList($id);
			}

			function showList($id=0) {
				$options=array();
				foreach($this->selectAll() as $row) {
					$selected = $row['id']==$id ? ' selected' : '';
					$options[]="<option value=\"$row[id]\"$selected>$row[details]</option>";
				}
				return implode('',$options);
			}

		/*	Controller
			================================================================ */

			function noData() {
				$data=array(
					'givenname'=>'',
					'familyname'=>'',
					'email'=>'',
					'id'=>0,
					'admin'=>false,
					'isadmin'=>'',
					'iscontributor'=>'',
					'password'=>'',
				);
				$this->data=array_merge($this->data,$data);
				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;

			}

			function getData() {
				$data=array(
					'givenname'=>trim($_POST['givenname']),
					'familyname'=>trim($_POST['familyname']),
					'email'=>trim($_POST['email']),
					'keeppassword'=>!!@$_POST['keeppassword'],
					'confirm'=>@$_POST['confirm'],
					'id'=>intval(@$_POST['id']),
					'admin'=>@$_POST['admin'],
					'contributor'=>@$_POST['contributor'],
				);
				if(!$data['keeppassword']) $data['password']=@$_POST['password'];

				$this->data=array_merge($this->data,$data);

#				$this->prepare($this->data['id']);

				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;
			}

			function sendConfirmationEmail($email,$confirmation) {
				$to=$email;
				$subject='Confirmation of Registration';
				$headers="From: info@prints.comparity.net";
				$message=<<<END
Someone, presumably you, has just registerd your email address.
If this is you, please confirm your registration by clicking on this link.
<a href="http://prints.comparity.net/register?email=$email&confirmation=$confirmation">Confirm</a>
END;
				mail($to,$subject,$message,$headers);
			}

			function checkLogin() {
				if(isset($_POST['login'])) {
					$pds=$this->pdo->prepare($this->sql['login']);
					$pds->execute(array('email'=>$_POST['email'],'password'=>sha1($_POST['password'])));
					if($row=$pds->fetch()) {	//	empty row if no match
						$_SESSION['email']=$_POST['email'];

						//	Allow test admin
							$_SESSION['live']=!!$_SESSION['user']==1;

						list($_SESSION['user'],$_SESSION['familyname'],$_SESSION['givenname'],$_SESSION['admin'])=$row;
							if(isset($_POST['remember'])) {
								$remember=rand();	//	Can improve on this
								$pds=$pdo->prepare('UPDATE users SET remember=? WHERE id=?');
								$pds->exec(array($remember,$_SESSION['user']));
								setcookie('remember',"$id:$remember",time()+2*3600,'/');	// 2 hours
							}
							$referrer=$_SERVER['HTTP_REFERER']?:'/';
							header("Location: $referrer"); exit;
					}
					else $error='<p class="error">Unsuccessful Login</p>';
				}

				if(isset($_POST['logout'])) {
					unset($_SESSION['user'],$_SESSION['admin'],$_SESSION['email'],$_SESSION['givenname'],$_SESSION['familyname']);
					//$_SESSION=array();
					//setcookie(session_name(),'',time()-24*60*60,'/');
					//session_destroy();
				}
/*
				if(!isset($_SESSION['user']) && isset($_COOKIE['remember'])) {
					list($id,$remember)=explode(':',$_COOKIE['remember']);
					$result=$connection->query("
					$sql='SELECT id,email,familyname,givenname FROM customers WHERE sha1(id)=? AND sha1(remember)=?;");
					$pds->prepare($sql);
					$pds->execute(array($id,$remember));
					if($row=$result->num_rows) {
						list($_SESSION['customer'],$_SESSION['familyname'],$_SESSION['givenname'],$_SESSION['email'])=$row;
						list($id,$email,$familyname,$givenname)=$row;
					}
				}
*/
			}

			function parms($string,$data) {
				foreach($data as $k=>$v) {
					$string=str_replace(":$k",$v,$string);
				}
				return $string;
			}


			function processButtons() {
				$id=0;
				$error=null;
				$this->noData();
				if(isset($_POST['select'])) {
					$id=intval(@$_POST['select']);
					if($id) {
						$this->select($id);
						$this->data['isadmin']=$this->data['admin']?' checked':'';
						$this->data['iscontributor']=$this->data['contributor']?' checked':'';
					}
				}

				if(isset($_POST['insert'])) {
					$data=$this->getData();
					$id=$data['id'];
					$error=$this->error();
					if($error) $id=0;
					else {
						$confirmation=uniqid('',true);
						$id=$this->add(array('email'=>$data['email'],'givenname'=>$data['givenname'],'familyname'=>$data['familyname'],'password'=>sha1($data['password']),'confirmation'=>$confirmation));
						$this->sendConfirmationEmail($data['email'],sprintf('%05d|%s',$id,$confirmation));
					}
					return true;
				}

				if(isset($_POST['update'])) {
					$data=$this->getData();
					$id=$data['id'];

					$error=$this->error(!$this->data['keeppassword']);
					if($error) $id=0;
					else {
						$password=$this->data['keeppassword'] ? $data['password'] : sha1($data['password']);
						$this->update(array('givenname'=>$data['givenname'],'familyname'=>$data['familyname'],
							'email'=>$data['email'],'admin'=>$data['admin'],'password'=>$password,'id'=>$id));
					}
				}

				if(isset($_POST['delete'])) {
					$data=$this->getData();
					$id=$data['id'];
					$this->delete(array($id));
					$this->noData();
					$id=0;
				}

				if(isset($_POST['doconfirmation'])) {
					list($id,$confirmation)=explode('|',$_POST['confirmation']);
					$id=intval($id);
#					print $this->parms($this->sql['confirm'],array('id'=>$id,'confirmation'=>$confirmation,'email'=>$_POST['email']));
					$this->execute($this->sql['confirm'],array('id'=>$id,'confirmation'=>$confirmation,'email'=>$_POST['email']));
					return true;
				}

				//	Fall Through
					$this->prepare($id);
					$error=$this->displayErrors($error);
					return array($id,$error);
			}

		function goodPassword($password) {
			return true;
		}

		function error($checkPassword=true) {
			$errors=array();
			//	Required
				if(!$this->data['givenname']) $errors[]='Missing Given Name';
				if(!$this->data['familyname']) $errors[]='Missing Family Name';

				if(!$this->data['email']) $errors[]='Missing Email Address';
				elseif(!isEmail($this->data['email'])) $errors[]='Invalid Email Address';
				elseif($this->checkDuplicate($this->data['email'],$this->data['id'])) $errors[]='User Email already exists';

				if($checkPassword) {
					if(!$this->data['password']) $errors[]='Missing Password';
					elseif(!$this->goodPassword($this->data['password'])) $errors[]='Not a good password';
					elseif($this->data['password']!=$this->data['confirm']) $errors[]='Password not confirmed';
				}
			return $errors?:false;
		}

	}

?>
