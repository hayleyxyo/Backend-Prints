<?php
	class Cart {
		protected $pdo;
		protected $cartName;
		public $data=array();

		public function __construct($pdo,$name='cart') {
			$this->name=$name;
			$this->pdo=$pdo;
			$this->restore();
		}

		/*	Model
			================================================================ */

			function save() {
				if(@$_SESSION['user'] && @$_SESSION[$this->name]) {
					$sql='UPDATE users SET cart=? WHERE id=?';
					$pds=$this->pdo->prepare($sql);
					$data=array(json_encode($_SESSION[$this->name]),$_SESSION['user']);
					$pds->execute($data);
				}
			}

			function restore() {
				return;
				if(@$_SESSION['user']) {
					$sql='SELECT cart FROM users WHERE id=%s';
					$data=$this->pdo->query(sprintf($sql,intval($_SESSION['user'])))->fetchColumn();
					$cart=$data ? json_decode($data,true) : array();
					if(isset($_SESSION[$this->name])) $cart=array_merge($_SESSION[$this->name],$cart);
					if($cart) $_SESSION[$this->name]=$cart;
				}
			}

			public function clear() {
				if(@$_SESSION['user'] && @$_SESSION[$this->name]) {
					$sql='UPDATE users SET cart=null WHERE id=?';
					$pds=$this->pdo->prepare($sql);
					$data=array($_SESSION['user']);
					$pds->execute($data);
				}
				unset($_SESSION[$this->name]);
			}

			function place() {
				if(!isset($_SESSION['user'])) return;
				$user=$_SESSION['user'];
				$email=$_SESSION['email'];
				$familyname=$_SESSION['familyname'];
				$givenname=$_SESSION['givenname'];

				$supplierEmail=$GLOBALS['CONFIG']['supplieremail'];

				if(@$_SESSION[$this->name]) {
					$sqlOrderItems='INSERT INTO orderitems (orderid,printid,price,quantity) VALUES (?,?,?,?);';
					$pdsOrderItems=$this->pdo->prepare($sqlOrderItems);
					$sqlPrintDetails='SELECT title,price,src,artistname FROM printdetails WHERE id=?';
					$pdsPrintDetails=$this->pdo->prepare($sqlPrintDetails);

					$totalPrice=0;

					$sqlOrder='INSERT INTO orders (customerid,total,orderdate) VALUES (?,?,now())';
					$pdsOrder=$this->pdo->prepare($sqlOrder);
					$pdsOrder->execute(array($user,$totalPrice));

					$orderid=$this->pdo->lastInsertId();
					$message=array("Order Confirmation No: $orderid");

					foreach($_SESSION[$this->name] as $id=>$quantity) {
						$pdsPrintDetails->execute(array($id));
						$row=$pdsPrintDetails->fetch();
						$pdsOrderItems->execute(array($orderid,$id,$row['price'],$quantity));
						$totalPrice+=$row['price']*$quantity;
						$message[]="$id: {$row['title']}\nUnit Price: {$row['price']}\nQuantity: $quantity";
					}

					$sqlOrder='UPDATE orders SET total=? WHERE customerid=?';
					$pdsOrder=$this->pdo->prepare($sqlOrder);
					$pdsOrder->execute(array($user,$totalPrice));

					$message[]="Order Total: $totalPrice\n";

					//	Customer Email
						$to="$givenname $familyname <$email>";
						$subject="TAFKAP Order No: $orderid";
						$headers="From: Customer Orders <$supplierEmail>\r\n";
						$message=implode("\r\n\r\n",$message);
						$sent=mail($to,$subject,$message,$headers); // ,$headers);

					//	Vendor Email
						$to="Supplier <$supplierEmail>";
						$subject="TAFKAP Order No: $orderid";
						$headers="$givenname $familyname <$email>\r\n";
#						$message=implode("\r\n\r\n",$message);
						$sent=mail($to,$subject,$message,$headers); // ,$headers);

					$this->clear();
					$this->data['ordered']=true;
				}

			}
		/*	View
			================================================================ */

			function prepare($checkout=false) {
				$this->data['list']=$this->showList($checkout);
			}

			function showList($checkout=false) {
				$cart='';
				$totalPrice=0;
				if(isset($_SESSION[$this->name])) {
					$cart=array();
					$sql="SELECT title,givenname,familyname,price,src,artistname FROM printdetails WHERE id=?";
					$pds=$this->pdo->prepare($sql);

					if($checkout) {
						$cart[]="<tr><th>ID</th><th>Image</th><th>Details</th><th>Price<th>Qty</th><th>Drop</th></tr>";
						$cartrow='<tr><td>%s<input type="hidden" name="id[]" value="%s"></td><td>%s</td><td>%s<br>%s</td><td>%s</td><td><input type="text" name="quantity[]" value="%s"></td><td><input type="checkbox" name="drop[%s]" value="1"></td></tr>';
					}
					else {
#						$cart[]="<tr><th>ID</th><th>Image</th><th>Details</th><th>Price<th>Qty</th><th>Drop</th></tr>";
						$cartrow='<tr><th>%s</th><td>%s</td><td><b>%s</b><br>%s</td><td>%s</td><td>%s</td><td><button name="remove[%s]"><img src="ui/picture_delete.png" alt="Drop" title="Remove from Shopping Cart"></button></td></tr>';
					}

					$thumbnailTemplate='<img src="images/cart/%s" title="%s" alt="Thumbnail">';
					foreach($_SESSION[$this->name] as $id=>$quantity) {
						$pds->execute(array($id));
						$row=$pds->fetch();
						$price=$row['price'];
						$totalPrice+=$price*$quantity;
						$price=number_format($price,2);
						$thumbnail=sprintf($thumbnailTemplate,$row['src'],$row['title']);
						if($checkout)	$cart[]=	sprintf($cartrow,$id,$id,$thumbnail,$row['title'],$row['artistname'],$price,$quantity,$id);
						else  			$cart[]=	sprintf($cartrow,$id,$thumbnail,$row['title'],$row['artistname'],$price,$quantity,$id);
					}
					$cart=implode('',$cart);
					$totalPrice='$AU '.number_format($totalPrice,2);
				}
				$this->data['cartitems']=$cart;
				$this->data['totalPrice']=$totalPrice;
				return array($cart,$totalPrice);
			}

		/*	Model
			================================================================ */

			function processButtons() {
				$id=0;
				$error=null;
				$this->data['ordered']=false;
#				$this->noData();

				/*	Shopping Cart
					================================================================ */

					if(isset($_POST['select'])) {
						$id=intval(@$_POST['select']);
						if($id) $this->select($id);
					}

					if(isset($_POST['add'])) {
						$id=intval(key($_POST['add']));
						@$_SESSION[$this->name][$id]++;
					}
					if(isset($_POST['remove'])) {
						$id=intval(key($_POST['remove']));
						@$_SESSION[$this->name][$id]--;
						if($_SESSION[$this->name][$id]<1) unset($_SESSION[$this->name][$id]);
						if(!$_SESSION[$this->name]) unset($_SESSION[$this->name]);
					}

				/*	Order
					================================================================ */

					if(isset($_POST['edit'])) {
						foreach($_POST['id'] as $k=>$v) {
							$_SESSION[$this->name][$v]=$_POST['quantity'][$k];
							if($_SESSION[$this->name][$v]<1) unset($_SESSION[$this->name][$v]);
						}
						if(isset($_POST['drop'])) foreach($_POST['drop'] as $k=>$v) {
							unset($_SESSION[$this->name][$k]);
						}
						if(!count($_SESSION[$this->name])) unset($_SESSION[$this->name]);
					}

					if(isset($_POST['order'])) {
						$this->place();
					}


				$this->data['user']=@$_SESSION['user']?:'';
				$this->data['email']=@$_SESSION['email']?:'';
				$this->data['familyname']=@$_SESSION['familyname']?:'';
				$this->data['givenname']=@$_SESSION['givenname']?:'';

				$this->save();
			}
	}

?>