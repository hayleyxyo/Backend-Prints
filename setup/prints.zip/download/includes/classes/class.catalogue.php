<?php

	require_once 'class.data.php';

	class Catalogue extends Data {
		protected $sql=array(
			'select'=>'SELECT givenname,familyname,aka FROM artists WHERE id=?',
			'selectAll'=>'SELECT id,givenname,familyname,aka FROM artists',
			'insert'=>'INSERT INTO artists (givenname,familyname,aka) VALUES (?,?,?)',
			'update'=>'UPDATE artists SET givenname=?, familyname=?, aka=? WHERE id=?',
			'delete'=>'DELETE FROM artists WHERE id=?',

			'selectSome'=>'SELECT id,title,src,price,givenname,familyname,description FROM printdetails ORDER BY id DESC LIMIT %s OFFSET %s',
			'count'=>'SELECT count(*) FROM prints',
		);

		function count() {
			return $this->pdo->query($this->sql['count'])->fetchColumn();
		}

		function selectSome($limit,$offset) {
			return $this->pdo->query(sprintf($this->sql['selectSome'],$limit,$offset));
		}

		function showSome($limit,$offset) {
			global $previewFolder, $thumbnailFolder, $thumbnailWidth, $thumbnailHeight;
			$prints=array();
	foreach($this->selectSome($limit,$offset) as $row) {
		$price='$AU '.number_format($row['price'],2);
		$prints[]=<<<END
<tr><th>{$row['id']}</th>
	<td><a class="light" href="$previewFolder/{$row['src']}"><img src="$thumbnailFolder/{$row['src']}" alt="{$row['title']}" title="{$row['title']}" width="$thumbnailWidth" height="$thumbnailHeight"></a></td>
	<td>{$row['givenname']} {$row['familyname']}<br>
		${row['title']}<br>
		Price: $price<br>
		<button name="add[{$row['id']}]"><img src="ui/picture_add.png" alt="Add" title="Add to Shopping Cart"></button>
	</td>
</tr>
END;

#$row['id'],$previewFolder/$row['src'],$thumbnailFolder/$row['src'],$row['title'],$row['title'],$thumbnailWidth,$thumbnailHeight,$row['givenname'],$row['familyname'],$row['title'],$price,$row['id']

	}
	return implode('',$prints);
		}


	}

?>
