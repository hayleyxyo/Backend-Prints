--mixed--$boundary

$message

--mixed--$boundary
Content-Type: application/zip; name="$printzip"
Content-Transfer-Encoding: base64
Content-Disposition: attachment

$data
--mixed--$boundary
