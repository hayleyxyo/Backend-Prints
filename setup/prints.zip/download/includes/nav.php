	<nav>
		<ul>
			<li><a href="/">Home</a></li>
			<li><a href="/contact">Contact</a></li>
			<li><a href="download.php">Download</a></li>
			<?php if(@$_SESSION['admin']): ?><li><a href="/admin">Administration</a></li><?php endif; ?>
		</ul>
	</nav>
