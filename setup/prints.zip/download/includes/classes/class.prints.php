<?php

	require_once 'class.data.php';
	require_once 'class.artists.php';
	require_once 'class.thumbnails.php';

	class Prints extends Data {
		protected $artists;
		protected $sql=array(
			'select'=>'SELECT id,title,artistid,price,size,description,src FROM prints WHERE id=%s',
			'selectAll'=>'SELECT id,title FROM prints',
			'insert'=>'INSERT INTO prints (artistid,title,price,size,description) VALUES (:artistid,:title,:price,:size,:description)',
			'insertImage'=>'INSERT INTO prints (artistid,title,price,size,description,src) VALUES (:artistid,:title,:price,:size,:description,:src)',
			'update'=>'UPDATE prints set artistid=:artistid,title=:title,price=:price,size=:size,description=:description WHERE id=:id',
			'updateImage'=>'UPDATE prints set src=:src WHERE id=:id',
			'delete'=>'DELETE FROM prints WHERE id=?'
		);

		function __construct($pdo,$config) {
			$this->artists=new Artists($pdo,$config);
			parent::__construct($pdo,$config);
		}

		/*	View
			================================================================ */

			function prepare($id=0) {
				$this->data['list']=$this->showList($id);
				$this->data['artists']=$this->artists->showAll($this->data['artistid']);
			}

			function showList($id=0) {
				$options=array();
				foreach($this->selectALL() as $row) {
					$selected = $row['id']==$id ? ' selected' : '';
					$options[]="<option value=\"$row[id]\"$selected>$row[title]</option>";
				}
				return $this->data['list']=implode('',$options);
			}

		/*	Controller
			================================================================ */

			function noData() {
				$data=array(
					'title'=>'',
					'description'=>'',
					'artistid'=>'',
					'price'=>'',
					'size'=>'',
					'id'=>0,
					'src'=>'',
					'oldsrc'=>'',
					'newsrc'=>false,
				);
				$this->data=array_merge($this->data,$data);
				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;

			}

			function getData($getImage=true) {
				$price=trim(@$_POST['price']);
				$price=preg_replace('/^\$/','',$price);
				$data=array(
					'title'=>trim(@$_POST['title']),
					'description'=>trim(@$_POST['description']),
					'artistid'=>intval(@$_POST['artistid']),
					'price'=>floatval($price),
					'size'=>trim(@$_POST['size']),
					'id'=>intval(@$_POST['id']),
					'oldsrc'=>trim(@$_POST['oldsrc']),
					'newsrc'=>!!@$_POST['newsrc'],
				);

				if($getImage || $data['newsrc']) $data['src']=$_FILES['src'];

				$this->data=array_merge($this->data,$data);

				$this->prepare($this->data['id']);

				$this->data=array_merge($this->data,array_values($this->data));
				return $this->data;
			}

			function doFileName($fileName,$id=0) {
				$fileName=strtolower($fileName);
				$fileName=str_replace(' ','-',$fileName);
				if($id) $fileName=fileNumber($fileName,$id);
				return $fileName;
			}

			function saveImage($fileName) {
				$CONFIG=$this->CONFIG;
				move_uploaded_file($this->data['src']['tmp_name'],"{$CONFIG['originalfolder']}/$fileName");
				$thumbnail=new Thumbnailer("{$CONFIG['originalfolder']}/$fileName",array('method'=>'pad'));

				$thumbnail->make("{$CONFIG['thumbnailfolder']}/$fileName",
					array('width'=>$CONFIG['thumbnailwidth'],'height'=>$CONFIG['thumbnailheight']));

				$thumbnail->make("{$CONFIG['sepiafolder']}/$fileName",
					array('width'=>$CONFIG['thumbnailwidth'],'height'=>$CONFIG['thumbnailheight'],'colour'=>'sepia'));

				$thumbnail->make("{$CONFIG['previewfolder']}/$fileName",
					array('width'=>$CONFIG['previewwidth'],'height'=>$CONFIG['previewheight']));

				$thumbnail->make("{$CONFIG['cartthumbfolder']}/$fileName",
					array('width'=>$CONFIG['cartthumbwidth'],'height'=>$CONFIG['cartthumbheight']));

				return $fileName;
			}

			function processButtons() {
				$id=0;
				$error=null;
				$this->noData();
				if(isset($_POST['select'])) {
					$id=intval(@$_POST['select']);
					if($id) $this->select($id);
				}

				if(isset($_POST['insert'])) {
					$src='';
					$data=$this->getData(true);
					$id=$data['id'];
					$error=$this->error(true);
					if($error) $id=0;
					else {
						$id=$this->add(array('artistid'=>$data['artistid'],'title'=>$data['title'],
							'price'=>$data['price'],'size'=>$data['size'],'description'=>$data['description']));
						$fileName=$this->doFileName($data['src']['name'],$id);
						$src=$this->saveImage($fileName);
						$this->execute($this->sql['updateImage'],array('src'=>$fileName,'id'=>$id));
					}
					$this->data['src']=$src;
				}

				if(isset($_POST['update'])) {
#					$this->GetData(false);
					$data=$this->getData(false);
					$id=$data['id'];
					$error=$this->error($this->data['newsrc']);
					if($error) $id=0;
					else {
						$this->update(array('artistid'=>$data['artistid'],'title'=>$data['title'],
							'price'=>$data['price'],'size'=>$data['size'],'description'=>$data['description'],'id'=>$id));
						if($this->data['newsrc']) {
							$fileName=$this->doFileName($data['src']['name'],$id);
							$src=$this->saveImage($fileName);
							$this->execute($this->sql['updateImage'],array('src'=>$fileName,'id'=>$id));
							$this->data['src']=$fileName;
						}
						else $this->data['src']=$this->data['oldsrc'];
					}

				}

				if(isset($_POST['delete'])) {
					$data=$this->getData();
					$this->data['src']=$this->data['oldsrc'];
					$id=$data['id'];
					$sql='SELECT count(*) FROM orderitems WHERE printid=?';
					$count=$this->fetchColumn($sql,array($id));

					if(!$count) {
						$this->delete(array($id));
						$this->noData();
						$id=0;
					}
					else $error=array('There are some orders for this print');
				}

				//	Fall Through
					$this->prepare($id);
					$error=$this->displayErrors($error);
					return array($id,$error);
			}


		function error($imageRequired=false) {
			//	Uses $_POST data
			$errors=array();
			//	Required
				if(!$this->data['title']) $errors[]='Missing Title';
				if(!$this->data['artistid']) $errors[]='Missing Artist';
				if($imageRequired) {
					if(!$this->data['src']) $errors[]='Missing Image';
					elseif($error=uploadError($this->data['src'],true)) $errors[]=$error;
				}
			//	Others
				if($this->data['price'] && !is_numeric($this->data['price'])) $errors[]='Invalid Price';
			return $errors?:false;
		}

	}
?>
