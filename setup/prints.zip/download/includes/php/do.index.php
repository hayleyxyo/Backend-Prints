<?php
	//	Ordering & Shopping Cart
		require_once('includes/classes/class.cart.php');
		$cart=new Cart($pdo,'cart');

	//	Login & Logout
		require_once('includes/classes/class.users.php');
		$users=new Users($pdo,$CONFIG);
		$users->checkLogin();
		if(isset($_POST['clearcart'])) $cart->clear();
		else $cart->save();


	//	Process Shopping
		$cart->processButtons();

	//	Display Shopping Cart
		list($cart,$totalPrice)=$cart->showList();

	//	Catalogue
		require_once('includes/php/do.catalogue.php');
?>