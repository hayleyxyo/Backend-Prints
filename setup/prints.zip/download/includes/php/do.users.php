<?php

	require_once 'includes/classes/class.users.php';
	$users=new Users($pdo,$CONFIG);

	list($id,$errors)=$users->processButtons();

#	$users->prepare();
	extract($users->data);

?>
