	<header>
		<h1><?php print $index['title']; ?></h1>
	</header>