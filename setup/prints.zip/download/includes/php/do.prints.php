<?php
	require_once 'includes/classes/class.prints.php';
	$prints=new Prints($pdo,$CONFIG);
	list($id,$errors)=$prints->processButtons();
	extract($prints->data);
?>
