<?php
	ini_set('display_errors', 1);
	error_reporting(E_ALL);

	//	Prepare
		session_start();
		header('Cache-Control: private');
		require_once('includes/pdo.php');
		require_once('includes/config.php');
		require_once('includes/library.php');
		$root=$_SERVER['WEB_ROOT'] = str_replace($_SERVER['SCRIPT_NAME'],"",$_SERVER['SCRIPT_FILENAME']);
	//	Page
		//	Default or Admin Pages Only
			$index['include']='templates/login.php';
			$index['title']='TAFKAP: Login';
			$index['php']='includes/php/do.login.php';

		switch(@$_GET['index']) {
			case 'login':
				$index['include']='templates/login.php';
				$index['title']='TAFKAP: Login';
				break;
			case 'register':
				$index['include']='templates/register.php';
				$index['title']='TAFKAP: User Registration';
				$index['php']='includes/php/do.register.php';
#printr($index);
#exit;
				break;
			case 'checkout':
				$index['include']='templates/checkout.php';
				$index['title']='TAFKAP: Shopping Cart';
				$index['php']='includes/php/do.checkout.php';
				break;
			case 'contact':
				$index['include']='templates/contact.php';
				$index['title']='TAFKAP: Contact Us';
				$index['php']='includes/php/do.contact.php';
				break;
			case 'admin':
				if (@$_SESSION['admin']) {
					$index['include']='templates/admin.php';
					$index['title']='TAFKAP: Administration';
				}
				break;
			case 'artists':
				if (@$_SESSION['admin']) {
					$index['include']='templates/artists.php';
					$index['title']='TAFKAP: Manage Artists';
					$index['php']='includes/php/do.artists.php';
				}
				break;
			case 'prints':
				if (@$_SESSION['admin']) {
					$index['include']='templates/prints.php';
					$index['title']='TAFKAP: Manage Prints';
					$index['php']='includes/php/do.prints.php';
				}
				break;
			case 'users':
				if (@$_SESSION['admin']) {
					$index['include']='templates/users.php';
					$index['title']='TAFKAP: Manage Users';
					$index['php']='includes/php/do.users.php';
				}
				break;
			default:
				$index['include']='templates/index.php';
				$index['title']='The Artworks Formally Known As Prints';
				$index['php']='includes/php/do.index.php';
		}
	//	Extra PHP
		if($index['php']) require_once $index['php'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title><?php print $index['title']; ?></title>
	<link rel="stylesheet" title="main" type="text/css" href="styles/styles.css">

	<link rel="stylesheet" type="text/css" href="styles/forms.css">
	<script type="text/javascript" src="scripts/lb.js"></script>
	<script type="text/javascript" src="scripts/javascript.js"></script>
	<style type="text/css">
		body {
			background-image: none !important;
			background-color: white !important;
			width: 800px;
			border: 4px solid black !important;
			margin: 0 auto;
		}
		body:hover {
			border-color: #666 !important;
		}
		div#body {
			height: 632px;
		}
		header, nav, footer {
			height: 56px
		}


	</style>
</head>
<body>
	<?php require_once 'includes/header.php'; ?>
	<?php require_once 'includes/nav.php'; ?>
<div id="body">
	<?php require_once $index['include']; ?>
</div>
	<?php require_once 'includes/footer.php'; ?>
</body>
</html>
