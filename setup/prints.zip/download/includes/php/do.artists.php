<?php
	require_once 'includes/classes/class.artists.php';
	$artists=new Artists($pdo,$CONFIG);

	list($id,$errors)=$artists->processButtons();
	extract($artists->data);
?>
