DROP DATABASE IF EXISTS prints;

CREATE DATABASE prints;
USE prints;

DELETE FROM mysql.user WHERE user='prints';
CREATE USER 'prints'@'localhost' IDENTIFIED BY 'secret';
GRANT SELECT,INSERT,UPDATE,DELETE ON prints.*  TO 'prints'@'localhost';
