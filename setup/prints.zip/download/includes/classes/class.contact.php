<?php

	class Contact {
		private $smtp;
		public $data=array();
		private $to;
		private $pdo;

		function __construct($smtp,$to,$pdo) {
			$this->smtp=$smtp;
			$this->to=$to;
			$this->pdo=$pdo;
		}

		function getData() {
			return $this->data=array(
				'email'=>trim(@$_POST['email'])?:'',
				'name'=>trim(@$_POST['name'])?:'',
				'subject'=>trim(@$_POST['subject'])?:'',
				'message'=>trim(@$_POST['message'])?:'',
			);
		}

		function error() {
			$error=array();
				if(!$this->data['email']) $error[]='Missing Email Address';
				elseif(!isEmail($this->data['email'])) $error[]='Invalid Email Address';
				if(!$this->data['name']) $error[]='Missing Name';
				if(!$this->data['subject']) $error[]='Missing Subject';
				if(!$this->data['message']) $error[]='Missing Message';
			return $error;
		}

		function send() {
			ini_set('SMTP',$this->smtp);

			$headers=array();
				$headers[]=sprintf('From: %s <%s>',$this->data['name'],$this->data['email']);
				$headers[]=sprintf('Cc: %s',$this->data['email']);
				$headers[]=sprintf('To: Info <%s>',$this->to);		//	Windows
			$headers=implode("\r\n",$headers);
			$from=sprintf('-f %s',$this->data['email']);

			mail($this->to,$this->data['subject'],$this->data['message'],$headers);
		}

		function process() {
			if(isset($_POST['preview'])) {
				$data=$this->getData();
				$error=$this->error();
				if(!$error) {
					$this->data['send']=true;
				}
				else {
					$this->data['send']=false;
					$this->data['error']=sprintf('<p class="error">%s</p>',implode('<br>',$error));
				}
			}
			if(isset($_POST['review'])) {
				$data=$this->getData();
					$this->data['send']=false;
			}
			if(isset($_POST['send'])) {
				$data=$this->getData();
				$error=$this->error();
				if(!$error) {
					$this->send();
					$sql='INSERT INTO contact(name,email,subject,message,date) VALUES(?,?,?,?,now())';
					$pds=$this->pdo->prepare($sql);
					$data=array($this->data['name'],$this->data['email'],$this->data['subject'],$this->data['message']);
					$pds->execute($data);
					return true;
				}
				else $this->data['error']=sprintf('<p class="error">%s</p>',implode('<br>',$error));
			}

			return false;
		}
	}


?>
