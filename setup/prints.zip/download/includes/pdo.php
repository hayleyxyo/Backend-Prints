<?php
	require_once 'config.php';

	$database='prints';
	$dsn="mysql:host=localhost;dbname=$database";
	$pdo=new DB($dsn,USER,PASSWORD,true);

	class DB extends PDO {
		function __construct($dsn,$user,$password,$development=false) {
			try {
				parent::__construct($dsn,USER,PASSWORD);
				if($development) $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch (PDOException $e) {
				die($e->getMessage());
			}
			$this->exec('SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;');
			$this->exec('SET SESSION sql_mode = \'ANSI\';');

			//				ANSI	MySQL
			//	||			Concat	or
			//	"			Field	Quote
			//	fn			fn (	fn(
			//	REAL		FLOAT	DOUBLE
			//	GROUP BY	Any		Field List only

			//	--sql-mode=REAL_AS_FLOAT,PIPES_AS_CONCAT,ANSI_QUOTES,IGNORE_SPACE,ONLY_FULL_GROUP_BY
			//	--transaction-isolation=SERIALIZABLE
		}

		//	Prepared

		function insert($sql,array $data) {
			$pds=$this->pdo->prepare($sql);
			$pds->execute($data);
			return $this->pdo->lastInsertId();
		}

		function update($sql,array $data) {
			return $this->execute($sql,$data);
		}

		function delete($delete,array $sql) {
			return $this->execute($sql,$data);
		}

		function execute($sql,array $data) {
			$pds=$this->pdo->prepare($sql);
			$pds->execute($data);
			return $pds->rowCount();
		}
	}

?>
